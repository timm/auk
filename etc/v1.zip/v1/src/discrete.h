
_Discrete
b
c

